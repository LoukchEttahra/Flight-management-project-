/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author oXCToo
 */
public class Client {
    //  the statements
   
    private String email;

    private String dob;

    private String gender;
   

    private int telNumber;

    private String firstname;
    private String lastname;
    
    // declare the getter ang setter
   
    public String getEmail ()
    {
        return email;
    }

    public void setEmail (String email)
    {
        this.email = email;
    }

    public String getDoB ()
    {
        return dob;
    }

    public void setDoB (String dob)
    {
        this.dob = dob;
    }

    public String getGender ()
           
    {
        return gender;
     
    }

   public void setGender (String gender)
   
    {
        this.gender = gender;
       
    }

    public int getTelNumber ()
    {
        return telNumber;
    }

    public void setTelNumber (int telNumber)
    {
        this.telNumber = telNumber;
    }

    public String getFirstname ()
    {
        return firstname ;
    }

    public void setFirstname  (String firstname)
    {
        this.firstname  = firstname;
    }
    public String getLastname ()
    {
        return lastname ;
    }

    public void setLastname  (String lastname)
    {
        this.lastname  = lastname;
    }
 

    @Override
    public String toString()
    {
        return "ClassPojo [email = "+email+", dob = "+dob+", gender = "+gender+", telNumber = "+telNumber+", firstname = "+firstname+",lastname = "+lastname+"]";
    }
}