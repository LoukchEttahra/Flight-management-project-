
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author oXCToo
 */
public class Reservation {

    private String passportNumber;

    private String dor;

    private int placeNumber;
   

    private int idClient;

    private int idFlight;
   
    // declare the getter ang setter
    public String getPassportNumber ()
    {
        return passportNumber;
    }

    public void setPassportNumber (String passportNumber)
    {
        this.passportNumber = passportNumber;
    }

  

    public String getDor ()
    {
        return dor;
    }

    public void setTxtDor (String dor)
    {
        this.dor = dor;
    }

    public int getPlaceNumber ()
           
    {
        return placeNumber;
     
    }

   public void setPlaceNumber (int placeNumber)
   
    {
        this.placeNumber = placeNumber;
       
    }

    public int getIdClient ()
    {
        return idClient;
    }

    public void setIdClient (int idClient)
    {
        this.idClient = idClient;
    }

    public int getIdFlight ()
    {
        return idFlight ;
    }

    public void setIdFlight  (int idFlight)
    {
        this.idFlight  = idFlight;
    }
    

  

    @Override
    public String toString()
    {
        return "ClassPojo [passportNumber = "+passportNumber+", dor = "+dor+", placeNumber = "+placeNumber+", idClient = "+idClient+", idFlight = "+idFlight+"]";
    }
}