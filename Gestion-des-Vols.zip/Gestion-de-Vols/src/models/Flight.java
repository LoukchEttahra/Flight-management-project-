/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author oXCToo
 */
public class Flight {

    
     private int line;

    private String dod;

    private String arrivalDate;
   

    private String departureTime;

    private String arrivingTime;
    private int price;
    
    // declare the getter ang setter
   
    public int getLine ()
    {
        return line;
    }

    public void setLine (int line)
    {
        this.line = line;
    }

  

    public String getDod ()
    {
        return dod;
    }

    public void setTxtDod (String dod)
    {
        this.dod = dod;
    }

    public String getArrivalDate ()
           
    {
        return arrivalDate;
     
    }

   public void setArrivalDate (String arrivalDate)
   
    {
        this.arrivalDate = arrivalDate;
       
    }

    public String getDepartureTime ()
    {
        return departureTime;
    }

    public void setDepartureTime (String departureTime)
    {
        this.departureTime = departureTime;
    }

    public String getArrivingTime ()
    {
        return arrivingTime ;
    }

    public void setArrivingTime  (String arrivingTime)
    {
        this.arrivingTime  = arrivingTime;
    }
    public int getPrice()
    {
        return price ;
    }

    public void setPrice  (int price)
    {
        this.price  = price;
    }
 

    @Override
    public String toString()
    {
        return "ClassPojo [line = "+line+", dod = "+dod+", arrivalDate = "+arrivalDate+", departureTime = "+departureTime+", arrivingTime = "+arrivingTime+", price = "+price+"]";
    }
}