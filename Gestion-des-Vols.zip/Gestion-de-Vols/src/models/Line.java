/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author pc
 */
public class Line {
    private int id;
    private String departure_Airoport;
    private String arrival_Airoport;
    private String departure_City ;
    private String arrival_City ;
    
    // declare the getter ang setter
    public int getId ()
    {
        return id;
    }

    public void setId (int id)
    {
        this.id = id;
    }
        public String getDaparture_Airoport ()
    {
        return departure_Airoport;
    }

    public void setDaparture_Airoport (String departure_Airoport)
    {
        this.departure_Airoport = departure_Airoport;
    }
        public String getArrival_Airoport ()
    {
        return arrival_Airoport;
    }

    public void setArrival_Airoport (String arrival_Airoport)
    {
        this.arrival_Airoport = arrival_Airoport;
    }
        public String getDaparture_City()
    {
        return departure_City;
    }

    public void setDaparture_City (String daparture_City)
    {
        this.departure_City = daparture_City;
    }
        public String getArrival_City ()
    {
        return arrival_City;
    }

    public void setArrival_City (String email)
    {
        this.arrival_City = arrival_City;
    }
}
