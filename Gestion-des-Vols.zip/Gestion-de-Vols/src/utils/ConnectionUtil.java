/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Fatima & Ettahra
 */
public class ConnectionUtil {
    Connection conn = null;
    public static Connection conDB()
    {
        // Step 1: Establishing a Connection and 
        // try-with-resource statement will auto close the connection.
        try {
            Class.forName("com.mysql.jdbc.Driver");
            // Replace below database url, with our actual database credentials
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/gestionvol", "root", "");
            return con;
        } catch (ClassNotFoundException | SQLException ex) {
            // print SQL exception information
            System.err.println("ConnectionUtil : "+ex.getMessage());
           return null;
        }
    }
    //make sure you add the lib
}
