/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Callback;
import models.Client;
import models.Line;
import utils.ConnectionUtil;

/**
 * FXML Controller class
 *
 * @author pc
 */
public class SearchLineController implements Initializable {
    //the statements
    @FXML
    private AnchorPane searchLineRoot;
    @FXML
    private Label lblStatus;
    @FXML
    private TextField filterField;
    @FXML
    private TableView tblData;
    
    PreparedStatement preparedStatement;
    Connection connection;

    public SearchLineController() {
        connection = (Connection) ConnectionUtil.conDB();   
    }
    
    //Create SQL Query
    private ObservableList<Line> data= FXCollections.observableArrayList();
    private ObservableList<ObservableList> data1 = FXCollections.observableArrayList();
    private ObservableList<ObservableList> data2 = FXCollections.observableArrayList();
    
     String SQL = "SELECT * from line";
     
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        //show data
        fetColumnList();
        fetRowList();
        //function search
        SearchLine();
    }    
    @FXML
    private void SearchLine() {
        // when mouse clicked
        filterField.setOnKeyReleased(e->{
            if(filterField.getText().equals("")){
               // loadDataFromDatabase();
            }else{
                data1.clear();
                 String sql = "SELECT *FROM line WHERE  departure_Airoport LIKE '%"+filterField.getText()+"%'"
                         +"UNION SELECT *FROM line WHERE  arrival_Airoport LIKE '%"+filterField.getText()+"%'"
                         +"UNION SELECT *FROM line WHERE  departure_City LIKE '%"+filterField.getText()+"%'"
                         +"UNION SELECT *FROM line WHERE  arrival_City LIKE '%"+filterField.getText()+"%'";
                try {
                    preparedStatement = (PreparedStatement) connection.prepareStatement(sql);
                    //preparedStatement.setString(1, filterField.getText());
                    ResultSet rs =  preparedStatement.executeQuery();
                    while (rs.next()) {
                        // System.out.println(""+rs.getString(2));
                        // data.add(new ProductList(rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7)));
                        ObservableList row = FXCollections.observableArrayList();
                        for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                            //Iterate Column
                            row.add(rs.getString(i));  
                        }
                        data1.add(row); 
                        }
                        tblData.setItems(data1);
                }catch (SQLException ex) {
                      System.err.println(ex.getMessage());
                }              
            }        
        });    
    }
    private void fetColumnList() {
        try {
            ResultSet rs = connection.createStatement().executeQuery(SQL);
            //SQL FOR SELECTING ALL OF CUSTOMER
            for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                //We are using non property style for making dynamic table
                final int j = i;
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i + 1).toUpperCase());
                col.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>() {
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });
                tblData.getColumns().removeAll(col);
                tblData.getColumns().addAll(col);

                System.out.println("Column [" + i + "] ");

            }

        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());

        }
    }
    
    //fetches rows and data from the list
    private void fetRowList() {
        ResultSet rs;
        try {
            rs = connection.createStatement().executeQuery(SQL);

            while (rs.next()) {
                //Iterate Row
                ObservableList row = FXCollections.observableArrayList();
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    //Iterate Column
                    row.add(rs.getString(i));
                }
                System.out.println("Row [1] added " + row);
                data1.add(row);
            }
            tblData.setItems(data1);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }
    // back to menu
    @FXML
    private void BackAction(ActionEvent event) throws IOException {
        
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("/fxml/Menu.fxml"));
        Parent menuRoot  = fxmlLoader.load();
        Scene scene = new Scene(menuRoot );
        Stage stage = (Stage) searchLineRoot.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    } 
}
