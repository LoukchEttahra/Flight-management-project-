
package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;


public class MenuController implements Initializable {
    //The statements
    @FXML
    private AnchorPane menuRoot;
    @FXML
    private BorderPane borderPane;
    
    //go to the menu
    @FXML
    void handleAddUser(ActionEvent event) throws IOException {
       
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("/fxml/LoginAdmin.fxml"));
        Parent addUserRoot  = fxmlLoader.load();        
        Scene scene = new Scene(addUserRoot);
        Stage stage = (Stage) menuRoot.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    // go to the flight interface
    @FXML
    void AddFlight(ActionEvent event) throws IOException {
     
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("/fxml/AddFlight.fxml"));
        Parent addFlightRoot  = fxmlLoader.load();
        Scene scene = new Scene(addFlightRoot );
        Stage stage = (Stage) menuRoot.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    // go to the reservation interface
    @FXML
    void AddReservation(ActionEvent event) throws IOException {

       FXMLLoader fxmlLoader = new FXMLLoader(); 
       fxmlLoader.setLocation(getClass().getResource("/fxml/AddReservation.fxml"));
       Parent addReservationRoot  = fxmlLoader.load();         
       Scene scene = new Scene(addReservationRoot );
       Stage stage = (Stage) menuRoot.getScene().getWindow();
       stage.setScene(scene);
       stage.show();    
    }
    // go to the add client interface  
   @FXML
    void handleAddClient(ActionEvent event) throws IOException {
   
       FXMLLoader fxmlLoader = new FXMLLoader();
       fxmlLoader.setLocation(getClass().getResource("/fxml/AddClient.fxml"));
       Parent addClientRoot  = fxmlLoader.load();
       Scene scene = new Scene(addClientRoot );
       Stage stage = (Stage) menuRoot.getScene().getWindow();
       stage.setScene(scene);
       stage.show();
    }
    // go to the search client interface
    @FXML
    void SearchClient(ActionEvent event) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("/fxml/SearchClient.fxml"));
        Parent searchClientRoot  = fxmlLoader.load(); 
        Scene scene = new Scene(searchClientRoot );
        Stage stage = (Stage) menuRoot.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    // go to the search flight interface
    @FXML
    void SearchFlight(ActionEvent event) throws IOException {
  
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("/fxml/SearchFlight.fxml"));
        Parent searchFlightRoot  = fxmlLoader.load();      
        Scene scene = new Scene(searchFlightRoot );
        Stage stage = (Stage) menuRoot.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    // go to the search reservation interface
    @FXML
    void SearchByClient(ActionEvent event) throws IOException {
  
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("/fxml/SearchClientReservation.fxml"));
        Parent SearchByClientRoot  = fxmlLoader.load();    
        Scene scene = new Scene(SearchByClientRoot );
        Stage stage = (Stage) menuRoot.getScene().getWindow();
        stage.setScene(scene);
        stage.show();      
    }
    // go to the add line interface
    @FXML
    private void handleAddLine(ActionEvent event) throws IOException {
           
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("/fxml/AddLine.fxml"));
        Parent SearchByClientRoot  = fxmlLoader.load();      
        Scene scene = new Scene(SearchByClientRoot );
        Stage stage = (Stage) menuRoot.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    // go to the search line interface
    @FXML
    private void SearchLine(ActionEvent event) throws IOException {
                     
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("/fxml/SearchLine.fxml"));
        Parent searchLineRoot  = fxmlLoader.load();
        Scene scene = new Scene(searchLineRoot );
        Stage stage = (Stage) menuRoot.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    // exit the menu
    @FXML
    public void quitter ( ActionEvent event){
        System.exit(0);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    


}
