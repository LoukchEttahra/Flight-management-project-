package controllers;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.Window;
import utils.ConnectionUtil;

/**
 *
 * @author oXCToo
 */
public class LoginAdminController implements Initializable {

    //The statements
    @FXML
    private Label lblErrors;

    @FXML
    private TextField txtUsername;

    @FXML
    private TextField txtPassword;

    @FXML
    private Button btnSignin;
    
    @FXML
    private AnchorPane addUserRoot;
    
    @FXML
    private CheckBox checkPass;
    
    // Create SQL Query
    Connection con = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    @FXML
    public void handleButtonAction(MouseEvent event) {
        
        if (event.getSource() == btnSignin) {
            //login here
            if (logIn().equals("Success")) {
                try {
                    //add you loading or delays - ;-)
                    Node node = (Node) event.getSource();
                    Stage stage = (Stage) node.getScene().getWindow();
                    //stage.setMaximized(true);
                    stage.close();
                    Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/fxml/AddUserLogin.fxml")));
                    stage.setScene(scene);
                    stage.show();
                } catch (IOException ex) {
                    System.err.println(ex.getMessage());
                }
            }       
        }
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //TODO
    }
    //connection
    public LoginAdminController() {
        con = ConnectionUtil.conDB();
    }
    
    //we gonna use string to check for status
    private String logIn() {
        Window owner = btnSignin.getScene().getWindow();
        String status = "Success";
        String email = txtUsername.getText();
        String password = txtPassword.getText();
        if(email.isEmpty() || password.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner,"Form Error!",
         "Empty credentials");//Error alerte
            status = "Error";
        } else {
            //query
            String sql = "SELECT * FROM admin Where email = ? and password = ?";
            try {
                preparedStatement = con.prepareStatement(sql);
                preparedStatement.setString(1, email);
                preparedStatement.setString(2, password);
                resultSet = preparedStatement.executeQuery();
                if (!resultSet.next()) {
                    showAlert(Alert.AlertType.ERROR, owner,"Form Error!",
                "Enter Correct Email/Password");//Error alerte
                    
                    status = "Error";
                } 
            } catch (SQLException ex) {
                System.err.println(ex.getMessage());
                status = "Exception";
            }
        }
        
        return status;
    }
    // back to menu
    @FXML
    private void BackAction(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("/fxml/Menu.fxml"));
        Parent menuRoot  = fxmlLoader.load();
        Scene scene = new Scene(menuRoot );
        Stage stage = (Stage) addUserRoot.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    //error color
    private void setLblError(Color color, String text) {
        lblErrors.setTextFill(color);
        lblErrors.setText(text);
        System.out.println(text);
    }
    // show alerte from any type
    private static void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.showAndWait();
    }
    //show password
    @FXML
    void ViewPassword(ActionEvent event) {
        if(checkPass.isSelected()){
            txtPassword.setPromptText(txtPassword.getText());
            txtPassword.setText("");
            txtPassword.setVisible(true);
        }else{
             txtPassword.setText(txtPassword.getPromptText());
            txtPassword.setPromptText("");
            txtPassword.setDisable(false);           
        }
    }
}
