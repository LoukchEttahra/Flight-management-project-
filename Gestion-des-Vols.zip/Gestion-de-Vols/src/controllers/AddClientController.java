/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Callback;
import utils.ConnectionUtil;


public class AddClientController implements Initializable {
    //The statements
    @FXML
    private AnchorPane addClientRoot; 
    
    @FXML
    Label lblStatus;
    
    @FXML
    private TextField txtFirstname;
    
    @FXML
    private TextField txtLastname;
    
    @FXML
    private DatePicker txtDOB;
    
    @FXML
    private ComboBox<String> txtGender;
    
    @FXML
    private TextField telNumber;
    
    @FXML
    private TextField txtEmail;
    
    @FXML
    private  TextField txtResearch; 
    
    @FXML
    private Button btnSearch;
    
    @FXML
    TableView tblData;
    
    //Create SQL Query
    PreparedStatement preparedStatement;
    Connection connection;
    
    private ObservableList<ObservableList> data;
    String SQL = "SELECT * from clients";

    public AddClientController() {
        connection = (Connection) ConnectionUtil.conDB();
    }
    /**
     * Initializes the controller class.
    */
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        //initialize gender
        txtGender.getItems().addAll("Male", "Female");
        txtGender.getSelectionModel().select("Male");
        // show data
        fetColumnList();
        fetRowList();
    }
    // back to menu
    @FXML
    void BackAction(ActionEvent event) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader();
         fxmlLoader.setLocation(getClass().getResource("/fxml/Menu.fxml"));
        Parent menuRoot  = fxmlLoader.load();
        Scene scene = new Scene(menuRoot );
        Stage stage = (Stage) addClientRoot.getScene().getWindow();
        stage.setScene(scene);
        stage.show(); 
    } 
    // test if all data is entered
    @FXML
    private void HandleEvents(MouseEvent event) {
        //check if not empty
        if (txtLastname.getText().isEmpty()||txtEmail.getText().isEmpty() || txtFirstname.getText().isEmpty() || telNumber.getText().isEmpty() || txtDOB.getValue().equals(null)) {
           lblStatus.setTextFill(Color.TOMATO);
           lblStatus.setText("Enter all details");
           
        }    
        else{
            saveClient();
        }
    }
    // clear all fields
    private void clearFields() {
        txtFirstname.clear();
        txtLastname.clear();
        telNumber.clear();
        txtEmail.clear();
        txtResearch.clear();
        txtDOB.getEditor().clear();
        this.txtGender.getSelectionModel().clearSelection();
        this.txtGender.setValue(null);
       
    }
    //***************************************
    //test email
    private boolean validateEmaill () {
        Pattern p = Pattern.compile ("[a-zA-Z0-9][a-zA-Z0-9._]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+");
        Matcher m = p.matcher (txtEmail.getText ());
        if (m.find () && m.group ().equals (txtEmail.getText ())){
        return true;
        }else{
        Alert alert = new Alert (AlertType.WARNING);
        alert.setTitle ("Validate Email");
        alert.setHeaderText (null);
        alert.setContentText ("Please Enter Valid Email");
        alert.showAndWait ();
        return false;
        }
    }
  
    // test last name
    private boolean validateLastName () {
        Pattern p = Pattern.compile ("^[a-zA-Z\\s]*$");
        Matcher m = p.matcher (txtLastname.getText ());
        if (m.find () && m.group ().equals (txtLastname.getText())){
        return true;
        }else{
        Alert alert = new Alert (AlertType.WARNING);
        alert.setTitle ("Validate Last Name");
        alert.setHeaderText (null);
        alert.setContentText ("Please Enter Valid Last Name");
        alert.showAndWait () ;
        return false;
        }
    }
    // test first name
    private boolean validateFirstName () {
        Pattern p = Pattern.compile ("^[a-zA-Z\\s]*$");
        Matcher m = p.matcher (txtFirstname.getText ());
        if (m.find () && m.group ().equals (txtFirstname.getText())){
        return true;
        }else{
        Alert alert = new Alert (AlertType.WARNING);
        alert.setTitle ("Validate First Name");
        alert.setHeaderText (null);
        alert.setContentText ("Please Enter Valid First Name");
        alert.showAndWait () ;
        return false;
        }
    }
    // test tel number
    private boolean validateMobileNo () {
        Pattern p = Pattern.compile ("[0-9]+");
        Matcher m = p.matcher (telNumber.getText ());
        if (m.find () && m.group ().equals (telNumber.getText ())){
        return true;
        }else{
        Alert alert = new Alert (AlertType.WARNING);
        alert.setTitle ("Validate Mobile Number");
        alert.setHeaderText (null);
        alert.setContentText ("Please Enter Valid Mobile Number");
        alert.showAndWait ();
        return false;
        }
    }
    //**********************************************
    //save data
    private String saveClient() {
        //test all data 
        if( validateFirstName () && validateLastName ()&& validateMobileNo () &&validateMobileNo () && validateEmaill ()){
            try {
                //query LIKE 
                String st = "INSERT INTO clients (firstname,lastname, gender, dob, telNumber, email) VALUES (?,?,?,?,?,?)";
                preparedStatement = (PreparedStatement) connection.prepareStatement(st);
                preparedStatement.setString(1, txtFirstname.getText());
                preparedStatement.setString(2, txtLastname.getText());
                preparedStatement.setString(3, txtGender.getValue().toString());
                preparedStatement.setString(4, txtDOB.getValue().toString());
                preparedStatement.setString(5, telNumber.getText());
                preparedStatement.setString(6, txtEmail.getText());
                preparedStatement.executeUpdate();
                lblStatus.setTextFill(Color.GREEN);
                lblStatus.setText("Added Successfully");
                fetRowList();
                clearFields();
                return "Success";
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                lblStatus.setTextFill(Color.TOMATO);
                lblStatus.setText(ex.getMessage());
                return "Exception";
            }
        }
        return null;
    }
    //only fetch columns
    private void fetColumnList() {
        
        try {
            ResultSet rs = connection.createStatement().executeQuery(SQL);
            //SQL FOR SELECTING ALL OF CUSTOMER
            for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                //We are using non property style for making dynamic table
                final int j = i;
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i + 1).toUpperCase());
                col.setCellValueFactory(new Callback<CellDataFeatures<ObservableList, String>, ObservableValue<String>>() {
                    public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });
                 tblData.getColumns().removeAll(col);
                tblData.getColumns().addAll(col);
                System.out.println("Column [" + i + "] ");
            }
        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    //fetches rows and data from the list
    private void fetRowList() {
        data = FXCollections.observableArrayList();
        ResultSet rs;
        try {
            rs = connection.createStatement().executeQuery(SQL);
            while (rs.next()) {
                //Iterate Row
                ObservableList row = FXCollections.observableArrayList();
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    //Iterate Column
                    row.add(rs.getString(i));
                }
                System.out.println("Row [1] added " + row);
                data.add(row);
            }
            tblData.setItems(data);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }
    // delete client
    @FXML
    void deleteClient(ActionEvent event) throws SQLException {
        //show confirmation alerte
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle ("Delete Confirmation");
        alert.setHeaderText (null);
        alert.setContentText ("Do you want to delete this Client?");
        alert.showAndWait();
        // delete client confirme
        if (alert.getResult() == ButtonType.OK) {
            
            String del = "DELETE FROM clients WHERE ID=?";
            preparedStatement = (PreparedStatement) connection.prepareStatement(del);
            preparedStatement.setString(1, txtResearch.getText());
            int rowsDeleted = preparedStatement.executeUpdate();
            fetRowList();
            clearFields();
            if (rowsDeleted > 0) {
                System.out.println("Client successfully deleted ");
            }else{
                //show alerte / CLIENT DOES NOT EXIST /
                alert = new Alert (AlertType.WARNING);
                alert.setTitle ("Client delete");
                alert.setHeaderText (null);
                alert.setContentText ("This client does not exist");
                alert.showAndWait ();
            }
            }else if (alert.getResult() == ButtonType.CANCEL) {
                // delete canceled
                txtResearch.clear();
                System.out.println("Vous avez cliquez sur CANCEL");
            }
    }  
    //*********************************************
    //Edit Client
    @FXML
    void editClient(ActionEvent event) throws SQLException {
        // test all data
        if(validateFirstName () && validateLastName ()&& validateMobileNo () &&validateMobileNo () && validateEmaill ()){
            try {
                //query LIKE 
                String query = "update clients set firstname=?,lastname=?, gender=?, dob=?, telNumber=?, email=? where ID='"+txtResearch.getText()+"'  ";
                preparedStatement = (PreparedStatement) connection.prepareStatement(query);
                preparedStatement.setString(1, txtFirstname.getText());
                preparedStatement.setString(2, txtLastname.getText());
                preparedStatement.setString(3, txtGender.getValue().toString());
                preparedStatement.setString(4, txtDOB.getValue().toString());
                preparedStatement.setString(5, telNumber.getText());
                preparedStatement.setString(6, txtEmail.getText());
                // preparedStatement.executeUpdate();
                lblStatus.setTextFill(Color.GREEN);
                lblStatus.setText("Client Successfully Updated");  
                preparedStatement.execute();
                preparedStatement.close();
                fetRowList();
                clearFields();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            lblStatus.setTextFill(Color.TOMATO);
            lblStatus.setText(ex.getMessage());
        }
    }}
    //search client
    @FXML
    void SearchClient(ActionEvent event) {
        if(event.getSource()== btnSearch){
            // search by ID
            String sql = "SELECT *FROM clients WHERE ID="+txtResearch.getText()+"";
            ResultSet rs;
            try {
                rs = connection.createStatement().executeQuery(sql);
              
                while (rs.next()) 
                {
                    
                    txtFirstname.setText(rs.getString("firstname"));
                    txtLastname.setText(rs.getString("lastname"));
                    txtGender.setValue(rs.getString("gender"));
                    ((TextField) txtDOB.getEditor()).setText(rs.getString("dob"));
                    telNumber.setText(rs.getString("telNumber"));
                    txtEmail.setText(rs.getString("email"));  
                }  
            } catch (SQLException ex) {
                System.err.println(ex.getMessage());
            }  
        }
    }
    
    @FXML
    void Initialization(ActionEvent event) {
        clearFields();
    }
}
    
        

    
    


