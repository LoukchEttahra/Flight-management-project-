/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Callback;
import utils.ConnectionUtil;

/**
 *
 * @author pc
 */
public class AddLineController implements Initializable {
    
    //The statements
    @FXML
    private TextField Depar_Airport;
    
    @FXML
    private TextField Arriv_Airport;
    
    @FXML
    private TextField Depar_city;
    
    @FXML
    private TextField arriv_city;
    
    @FXML
    private TableView tblData;
    
    @FXML
    private Label lblStatus;
    
    @FXML
    private TextField txtResearch;
    
    @FXML
    private AnchorPane addLineRoot;
    
    PreparedStatement preparedStatement;
    Connection connection;
    //Create SQL Query
    private ObservableList<ObservableList> data;
    String SQL = "SELECT * from line";
    //connection
    public AddLineController() {
        connection = (Connection) ConnectionUtil.conDB();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        fetColumnList();//show data
        fetRowList();
    }    

    @FXML
    private void HandleEvents(MouseEvent event) {
        //check if not empty
        if (Depar_Airport.getText().isEmpty()||Arriv_Airport.getText().isEmpty() || Depar_city.getText().isEmpty() || arriv_city.getText().isEmpty()) {
           lblStatus.setTextFill(Color.TOMATO);
           lblStatus.setText("Enter all details");          
        } else {
            saveLine();
        }
    }
    // clear all fields
    private void clearFields() {
        Depar_Airport.clear();
        Arriv_Airport.clear();
        Depar_city.clear();
        arriv_city.clear();
        txtResearch.clear(); 
    }
    // test Departure City ( enter only letter)
    private boolean validateDepartureCity () {
        Pattern p = Pattern.compile ("^[a-zA-Z\\s]*$");
        Matcher m = p.matcher (Depar_city.getText ());
        if (m.find () && m.group ().equals (Depar_city.getText())){
        return true;
        }else{
        Alert alert = new Alert (AlertType.WARNING);
        alert.setTitle ("Validate Departure City");
        alert.setHeaderText (null);
        alert.setContentText ("Please Enter Valid Departure City");
        alert.showAndWait () ;
        return false;
        }
    } 
    // test Arriving City ( enter only letter)
    private boolean validateArrivalCity() {
        Pattern p = Pattern.compile ("^[a-zA-Z\\s]*$");
        Matcher m = p.matcher (arriv_city.getText ());
        if (m.find () && m.group ().equals (arriv_city.getText())){
        return true;
        }else{
        Alert alert = new Alert (AlertType.WARNING);
        alert.setTitle ("Validate Arrival City");
        alert.setHeaderText (null);
        alert.setContentText ("Please Enter Valid Arrival City");
        alert.showAndWait () ;
        return false;
        }
    } 
    // back to menu
    @FXML
    private void BackAction(ActionEvent event) throws IOException {
        
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("/fxml/Menu.fxml"));
        Parent menuRoot  = fxmlLoader.load();
        Scene scene = new Scene(menuRoot );
        Stage stage = (Stage) addLineRoot.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    // delete line
    @FXML
    private void deleteLine(ActionEvent event) throws SQLException {
        //show confirmation alerte
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle ("Delete Confirmation");
        alert.setHeaderText (null);
        alert.setContentText ("Do you want to delete ?");
        alert.showAndWait();
        if (alert.getResult() == ButtonType.OK) {
        // delete flight confirme
        String del = "DELETE FROM line WHERE ID=?";
        preparedStatement = (PreparedStatement) connection.prepareStatement(del);
        preparedStatement.setString(1, txtResearch.getText());
        int rowsDeleted = preparedStatement .executeUpdate();
        fetRowList();
        //clear fields
        clearFields();
        if (rowsDeleted > 0) {
           System.out.println("Line successfully deleted ");
        } else{
           //show alerte / FLIGHT DOES NOT EXIST /
           alert = new Alert (Alert.AlertType.WARNING);
           alert.setTitle ("Line delete");
           alert.setHeaderText (null);
           alert.setContentText ("This Line does not exist");
           alert.showAndWait ();
        }
        }else if (alert.getResult() == ButtonType.CANCEL) {
           txtResearch.clear();
           System.out.println("Vous avez cliquez sur CANCEL");
        }
    }
    //save line
    @FXML
    private String saveLine() {
        //test all data 
        if(validateDepartureCity () && validateArrivalCity ()){
            try {
                //query LIKE 
                String st = "INSERT INTO line (departure_Airoport,arrival_Airoport,departure_City,arrival_City) VALUES (?,?,?,?)";
                preparedStatement = (PreparedStatement) connection.prepareStatement(st);
                preparedStatement.setString(1, Depar_Airport.getText());
                preparedStatement.setString(2, Arriv_Airport.getText());
                preparedStatement.setString(3, Depar_city.getText());
                preparedStatement.setString(4, arriv_city.getText());
                preparedStatement.executeUpdate();
                lblStatus.setTextFill(Color.GREEN);
                lblStatus.setText("Added Successfully");
                fetRowList();
                //clear fields
                clearFields();
                return "Success";
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                lblStatus.setTextFill(Color.TOMATO);
                lblStatus.setText(ex.getMessage());
                return "Exception";
            }
        }
        return null;
    }
    
    //only fetch columns
    private void fetColumnList() {

        try {
            ResultSet rs = connection.createStatement().executeQuery(SQL);

            //SQL FOR SELECTING ALL OF CUSTOMER
            for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                //We are using non property style for making dynamic table
                final int j = i;
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i + 1).toUpperCase());
                col.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>() {
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });

                tblData.getColumns().removeAll(col);
                tblData.getColumns().addAll(col);

                System.out.println("Column [" + i + "] ");

            }

        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());
        }
    }
    //fetches rows and data from the list
    private void fetRowList() {
        data = FXCollections.observableArrayList();
        ResultSet rs;
        try {
            rs = connection.createStatement().executeQuery(SQL);

            while (rs.next()) {
                //Iterate Row
                ObservableList row = FXCollections.observableArrayList();
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    //Iterate Column
                    row.add(rs.getString(i));
                }
                System.out.println("Row [1] added " + row);
                data.add(row);

            }

            tblData.setItems(data);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }
    //edit line
    @FXML
    private void editLine(ActionEvent event) {
        //test all data
        if(validateDepartureCity () && validateArrivalCity ()){
            try {
                //query LIKE 
                String query = "update line set  departure_Airoport=?, arrival_Airoport=?, departure_City=?, arrival_City=? where ID='"+txtResearch.getText()+"'  ";
                preparedStatement = (PreparedStatement) connection.prepareStatement(query);
                preparedStatement.setString(1, Depar_Airport.getText());
                preparedStatement.setString(2, Arriv_Airport.getText());
                preparedStatement.setString(3, Depar_city.getText());
                preparedStatement.setString(4, arriv_city.getText());
                // preparedStatement.executeUpdate();
                lblStatus.setTextFill(Color.GREEN);
                lblStatus.setText("Line Successfully Updated");
                preparedStatement.execute();
                preparedStatement.close();
                fetRowList();
                clearFields();
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                lblStatus.setTextFill(Color.TOMATO);
                lblStatus.setText(ex.getMessage());
            }
        }
    }
    // search line
    @FXML
    private void SearchLine(ActionEvent event) {
        // search by ID
        String sql = "SELECT *FROM line WHERE ID="+txtResearch.getText()+"";
        ResultSet rs;
        try {
            rs = connection.createStatement().executeQuery(sql);
            while (rs.next()) {
            //Iterate Row
                String query = "update line set ID=? , departure_Airoport=?, arrival_Airoport=?, departure_City=?, arrival_City=?, where ID='"+txtResearch.getText()+"'  ";
                Depar_Airport.setText(rs.getString("departure_Airoport"));
                Arriv_Airport.setText(rs.getString("arrival_Airoport"));
                Depar_city.setText(rs.getString("departure_City"));
                arriv_city.setText(rs.getString("arrival_City"));
            }

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @FXML
    private void Initialization(ActionEvent event) {
        clearFields();
    }
    
}
