/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Callback;
import utils.ConnectionUtil;

/**
 * FXML Controller class
 *
 * @author oXCToo
 */
public class AddFlightController implements Initializable {
     
    //the statements
    @FXML
    private AnchorPane addFlightRoot;

    @FXML
    private ComboBox<String> idLine;
    
    @FXML
    private TextField departureTime;

    @FXML
    private TextField arrivingTime;

    @FXML
    private DatePicker txtDOD;

    @FXML
    private DatePicker arrivalDate;

    @FXML
    private TextField txtPrice;

    @FXML
    TableView  tblData;

    @FXML
    private Label lblStatus;

    @FXML
    private TextField txtResearch;
    
    PreparedStatement preparedStatement;
    Connection connection;
    
    //Create SQL Query
    private ObservableList<ObservableList> data;
    String SQL = "SELECT * from flights";

    public AddFlightController() {
        connection = (Connection) ConnectionUtil.conDB();
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //call the combobox fonction
        Fillcombobox();
        //validate daparture date (submit futur date from today)
        txtDOD.setDayCellFactory(picker -> new DateCell() {
        public void updateItem(LocalDate date, boolean empty) {
            super.updateItem(date, empty);
            LocalDate today = LocalDate.now();
            setDisable(empty || date.compareTo(today) < 0 );
        }
        });
        //validate arrival date (submit futur date from today)
        arrivalDate.setDayCellFactory(picker -> new DateCell() {
        public void updateItem(LocalDate date, boolean empty) {
            super.updateItem(date, empty);
            LocalDate today = LocalDate.now();
            setDisable(empty || date.compareTo(today) < 0 );
        }
        }); 
        //show data
        fetColumnList();
        fetRowList();
    }
    
    @FXML
    private void HandleEvents(MouseEvent event) {
        //check if not empty
        if (idLine.getValue().equals(null)||departureTime.getText().isEmpty() || arrivingTime.getText().isEmpty() || arrivalDate.getValue().equals(null) || txtDOD.getValue().equals(null)) {
           lblStatus.setTextFill(Color.TOMATO);
           lblStatus.setText("Enter all details");
           
        } else {
            saveFlight();
        }

    }
    //clear all fields
    private void clearFields() {
       
        departureTime.clear();
        arrivingTime.clear();
        arrivalDate.getEditor().clear();
        txtDOD.getEditor().clear();
        txtPrice.clear();
        txtResearch.clear();
        this.idLine.getSelectionModel().clearSelection();
        this.idLine.setValue(null);   
    }
    // back to menu
    @FXML
    void BackAction(ActionEvent event) throws IOException {

       FXMLLoader fxmlLoader = new FXMLLoader();
       fxmlLoader.setLocation(getClass().getResource("/fxml/Menu.fxml"));
       Parent menuRoot  = fxmlLoader.load();
       Scene scene = new Scene(menuRoot );
       Stage stage = (Stage) addFlightRoot.getScene().getWindow();
       stage.setScene(scene);
       stage.show();

    } 
    // complete the combobox with existing clients
    public void Fillcombobox() {
        
       ObservableList<String> listacombo= FXCollections.observableArrayList();
        //query LIKE 
       String st = "select * from line";
       try{
            preparedStatement = (PreparedStatement) connection.prepareStatement(st);
            ResultSet rs =preparedStatement.executeQuery(st);
              
            while ( rs.next() )
            {
               listacombo.add(
               rs.getString("ID")
               );       
               idLine.setItems(listacombo);
            }
        } catch (SQLException e) {
           e.printStackTrace();
        }  
    }
    //**********************************************
  
    // test Departure Time
    private boolean validateDepartureTime () {
        Pattern p = Pattern.compile ("([01]?[0-9]|2[0-3]):[0-5][0-9]");
        Matcher m = p.matcher (departureTime.getText ());
        if (m.find () && m.group ().equals (departureTime.getText())){
        return true;
        }else{
        Alert alert = new Alert (AlertType.WARNING);
        alert.setTitle ("Validate Time");
        alert.setHeaderText (null);
        alert.setContentText ("Please Enter Valid Time");
        alert.showAndWait () ;
        return false;
        }
    }
    // test Arriving Time
    private boolean validateArrivinTime () {
        Pattern p = Pattern.compile ("([01]?[0-9]|2[0-3]):[0-5][0-9]");
        Matcher m = p.matcher (arrivingTime.getText ());
        if (m.find () && m.group ().equals (arrivingTime.getText())){
        return true;
        }else{
        Alert alert = new Alert (AlertType.WARNING);
        alert.setTitle ("Validate Time");
        alert.setHeaderText (null);
        alert.setContentText ("Please Enter Valid Time");
        alert.showAndWait () ;
        return false;
        }
    }
    // test if departue date before arriving date
    private boolean validateDate () { 
        String localDate  = txtDOD.getValue().toString();
        String localDate1  = arrivalDate.getValue().toString();
          
        if(localDate.compareTo(localDate1) >= 0 ){
            System.out.println("Date1 is after Date2");
            Alert alert = new Alert (Alert.AlertType.WARNING);
            alert.setTitle ("Validate Date");
            alert.setHeaderText (null);
            alert.setContentText ("Please Enter Valid departure Date and Arriving Date");
            alert.showAndWait ();
            return false;
        }
        if(localDate.compareTo(localDate1) <= 0){
            System.out.println("Date1 is before Date2");
            return true;
        }   
        return false;
    } 
    //****************************************************
    // delete flight
    @FXML
    void deleteFlight(ActionEvent event) throws SQLException {
        // show delete alerte confirmation 
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle ("Delete Confirmation");
        alert.setHeaderText (null);
        alert.setContentText ("Do you want to delete ?");
        alert.showAndWait();
        // delete if flight exist
        if (alert.getResult() == ButtonType.OK) {
            String del = "DELETE FROM flights WHERE ID=?";
            preparedStatement = (PreparedStatement) connection.prepareStatement(del);
            preparedStatement.setString(1, txtResearch.getText());
            int rowsDeleted = preparedStatement .executeUpdate();
            fetRowList();
            //clear fields
            clearFields();
            if (rowsDeleted > 0) {
                System.out.println("Flight successfully deleted ");
            } else{ 
                // show alerte that flight does not exist
                alert = new Alert (AlertType.WARNING);
                alert.setTitle ("Flight delete");
                alert.setHeaderText (null);
                alert.setContentText ("This Flight does not exist");
                alert.showAndWait ();
            }
            }else if (alert.getResult() == ButtonType.CANCEL) {
                // delete canceled
                txtResearch.clear();
                System.out.println("Vous avez cliquez sur CANCEL");
            }
    }
   //*********************************************
    //save data
    @FXML
    private String saveFlight() {
        // test all data
        if( validateArrivinTime () && validateDepartureTime ()&& validateDate ()){
            try {
                //query LIKE 
                String st = "INSERT INTO flights (line,dod, arrivalDate,departureTime,arrivingTime, price) VALUES (?,?,?,?,?,?)";
                preparedStatement = (PreparedStatement) connection.prepareStatement(st);
                preparedStatement.setString(1, idLine.getValue().toString());
                preparedStatement.setString(2, txtDOD.getValue().toString());
                preparedStatement.setString(3, arrivalDate.getValue().toString());
                preparedStatement.setString(4, departureTime.getText());
                preparedStatement.setString(5, arrivingTime.getText());
                preparedStatement.setString(6, txtPrice.getText());
                preparedStatement.executeUpdate();
                lblStatus.setTextFill(Color.GREEN);
                lblStatus.setText("Added Successfully");
                fetRowList();  
                clearFields();
                return "Success";
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                lblStatus.setTextFill(Color.TOMATO);
                lblStatus.setText(ex.getMessage());
                return "Exception";
            }
        }
        return null;
    }
    
    //only fetch columns
    private void fetColumnList() {

        try {
            ResultSet rs = connection.createStatement().executeQuery(SQL);

            //SQL FOR SELECTING ALL OF CUSTOMER
            for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                //We are using non property style for making dynamic table
                final int j = i;
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i + 1).toUpperCase());
                col.setCellValueFactory(new Callback<CellDataFeatures<ObservableList, String>, ObservableValue<String>>() {
                    public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });
                tblData.getColumns().removeAll(col);
                tblData.getColumns().addAll(col);
                System.out.println("Column [" + i + "] ");
            }
        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());
        }
    }

    //fetches rows and data from the list
    private void fetRowList() {
        data = FXCollections.observableArrayList();
        ResultSet rs;
        try {
            rs = connection.createStatement().executeQuery(SQL);

            while (rs.next()) {
                //Iterate Row
                ObservableList row = FXCollections.observableArrayList();
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    //Iterate Column
                    row.add(rs.getString(i));
                }
                System.out.println("Row [1] added " + row);
                data.add(row);

            }

            tblData.setItems(data);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }
    //edit data
    @FXML
    void editFlight(ActionEvent event)throws SQLException {
        // test all data
        if(validateArrivinTime () && validateDepartureTime ()&& validateDate ()){
            try {
                 //query LIKE 
                String query = "update flights set line=?, dod=?,arrivalDate=?, departureTime=?, arrivingTime=?, price=? where ID='"+txtResearch.getText()+"'  ";
                preparedStatement = (PreparedStatement) connection.prepareStatement(query);
                preparedStatement.setString(1, idLine.getValue());
                preparedStatement.setString(2, txtDOD.getValue().toString());
                preparedStatement.setString(3, arrivalDate.getValue().toString());
                preparedStatement.setString(4, departureTime.getText());
                preparedStatement.setString(5, arrivingTime.getText());
                preparedStatement.setString(6, txtPrice.getText());
               // preparedStatement.executeUpdate();
                lblStatus.setTextFill(Color.GREEN);
                lblStatus.setText("Flight Successfully Updated");
                preparedStatement.execute();
                preparedStatement.close();
                fetRowList();
                clearFields();
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                lblStatus.setTextFill(Color.TOMATO);
                lblStatus.setText(ex.getMessage()); 
            }
        }
    }
    //search client by ID
    @FXML
    void SearchFlight(ActionEvent event) {
        
        String sql = "SELECT *FROM flights WHERE ID="+txtResearch.getText()+"";
        ResultSet rs;
        try {
            rs = connection.createStatement().executeQuery(sql);
            while (rs.next()) {
                //Iterate Row
                String query = "update flights set line=? , dod=?,arrivalDate=?, departureTime=?, arrivingTime=?, price=? where ID='"+txtResearch.getText()+"'  ";
              
                idLine.setValue(rs.getString("line"));
                departureTime.setText(rs.getString("departureTime"));
                ((TextField) txtDOD.getEditor()).setText(rs.getString("dod"));
                ((TextField) arrivalDate.getEditor()).setText(rs.getString("arrivalDate"));
                arrivingTime.setText(rs.getString("arrivingTime"));
                txtPrice.setText(rs.getString("price"));
            }       
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }
    @FXML
    void Initialization(ActionEvent event) {
        clearFields();
    }
    
}
