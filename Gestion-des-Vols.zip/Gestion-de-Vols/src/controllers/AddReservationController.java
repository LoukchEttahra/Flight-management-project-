/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Callback;
import utils.ConnectionUtil;

/**
 *
 * @author pc
 */
public class AddReservationController implements Initializable {
    //the statements
    @FXML
    private AnchorPane addReservationRoot;
    @FXML
    private TextField passportNum;
    @FXML
    private DatePicker txtDOR;
    @FXML
    private TextField PlaceNumber;
    @FXML
    private ComboBox<String> idClient;
    @FXML
    private ComboBox<String> idFlight;
    @FXML
    TableView tblData;
    @FXML
    private Label lblStatus;
    @FXML
    private TextField txtResearch;
    @FXML
    private RadioButton reservationType1;
    @FXML
    private RadioButton type1;
    @FXML
    private RadioButton reservationType2;
    @FXML
    private RadioButton type2;
    
    PreparedStatement preparedStatement;
    Connection connection;
    // Create query LIKE 
    private ObservableList<ObservableList> data;
    String SQL = "SELECT * from reservations";
    
    public AddReservationController() {
        connection = (Connection) ConnectionUtil.conDB();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        reservationType1.setSelected(true);
        type2.setSelected(true);
        // call comboboxs fonction
        Fillcombobox();
        Fillcombobox1();
        //validate Local date (submit futur date from today)
        txtDOR.setDayCellFactory(picker -> new DateCell() {
        public void updateItem(LocalDate date, boolean empty) {
            super.updateItem(date, empty);
            LocalDate today = LocalDate.now();

            setDisable(empty || date.compareTo(today) < 0 );
        }
        });
        // show data
        fetColumnList();
        fetRowList();
    }  
    @FXML
    private void HandleEvents(MouseEvent event) {
        //check if not empty
        if (passportNum.getText().isEmpty()||idClient.getValue().equals(null)||idFlight.getValue().equals(null)||txtDOR.getValue().equals(null)||
            PlaceNumber.getText().isEmpty()||reservationType1.getText().isEmpty()&&reservationType2.getText().isEmpty()||
            type1.getText().isEmpty()&&type2.getText().isEmpty()) {
            lblStatus.setTextFill(Color.TOMATO);
            lblStatus.setText("Enter all details");      
        } else {
            saveReservation();
        } 
    }
    // clear all fields
    private void clearFields() {
        passportNum.clear();
        PlaceNumber.clear(); 
        txtDOR.getEditor().clear();
        txtResearch.clear();
        reservationType1.setSelected(false);
        reservationType2.setSelected(false);
        type1.setSelected(false);
        type2.setSelected(false);
        this.idClient.getSelectionModel().clearSelection();
        this.idClient.setValue(null);
        this.idFlight.getSelectionModel().clearSelection();
        this.idFlight.setValue(null);
        
    }
    // complete the combobox with existing flight
    public void Fillcombobox() {
       ObservableList<String> listacombo= FXCollections.observableArrayList();
       String del = "select * from flights";
       try{
            preparedStatement = (PreparedStatement) connection.prepareStatement(del);
            ResultSet rs =preparedStatement.executeQuery(del);
              
            while ( rs.next() ){
                listacombo.add(
                rs.getString("ID")
                );
                idFlight.setItems(listacombo);
            } 
        } catch (SQLException e) {
           e.printStackTrace();
        }  
    }
    // complete the combobox with existing clients
    public void Fillcombobox1() {
       ObservableList<String> listacombo1 = FXCollections.observableArrayList();
        
       String del = "select * from clients";
       try{
         
            preparedStatement = (PreparedStatement) connection.prepareStatement(del);
            ResultSet rs =preparedStatement.executeQuery(del);
             while ( rs.next() )
            {
                listacombo1.add(
                rs.getString("ID")
                );
                idClient.setItems(listacombo1);
            } 
        } catch (SQLException e) {
           e.printStackTrace();
        }   
    }
    //back to menu
    @FXML
    private void BackAction(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("/fxml/Menu.fxml"));
        Parent menuRoot  = fxmlLoader.load();
        Scene scene = new Scene(menuRoot );
        Stage stage = (Stage) addReservationRoot.getScene().getWindow();
        stage.setScene(scene);
        stage.show();  
    }
    //*********************************************
    // delete reservation
    @FXML
    private void deleteReservation(ActionEvent event) throws SQLException {
        // show delete alerte confirmation 
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle ("Delete Confirmation");
        alert.setHeaderText (null);
        alert.setContentText ("Are you sure you want to delete this reservation ?");
        alert.showAndWait();
         // delete if flight exist
        if (alert.getResult() == ButtonType.OK) {

            String del = "DELETE FROM reservations WHERE ID=?";
            preparedStatement = (PreparedStatement) connection.prepareStatement(del);
            preparedStatement.setString(1, txtResearch.getText());
            int rowsDeleted = preparedStatement .executeUpdate();
            fetRowList();
            //clear fields
            clearFields();
            if (rowsDeleted > 0) {
                System.out.println("Reservation successfully deleted");
            } else{
                // show alerte that flight does not exist
                alert = new Alert (Alert.AlertType.WARNING);
                alert.setTitle ("Reservation delete");
                alert.setHeaderText (null);
                alert.setContentText ("This Reservation does not exist");
                alert.showAndWait ();
            }
        }else if (alert.getResult() == ButtonType.CANCEL) {
            // delete canceled
            txtResearch.clear();
            System.out.println("Vous avez cliquez sur CANCEL");
        }
       
    }
    //********************************************* 
    // test place number
    private boolean validaPlaceNumber() {
        Pattern p = Pattern.compile ("\\d{1}|\\d{9}");
        Matcher m = p.matcher (PlaceNumber.getText());
        if (m.find () && m.group ().equals (PlaceNumber.getText () )) {
        return true;
        }else{
        Alert alert = new Alert (Alert.AlertType.WARNING);
        alert.setTitle ("Validate PlaceNumber");
        alert.setHeaderText (null);
        alert.setContentText ("Please Enter Valid Place Number");
        alert.showAndWait () ;
        return false;
        }
    } 
    // test passport
    private boolean validatePassport () {
        Pattern p = Pattern.compile ("[A-Z]{2}[0-9]{7}");
        Matcher m = p.matcher (passportNum.getText ());
        if (m.find () && m.group ().equals (passportNum.getText ())){
        return true;
        }else{
        Alert alert = new Alert (Alert.AlertType.WARNING);
        alert.setTitle ("Validate PassPort");
        alert.setHeaderText (null);
        alert.setContentText ("Please Enter Valid PassPort");
        alert.showAndWait ();
        return false;
        } 
    } 
    //*********************************************
    // get the reservation type selected
    public String radioselected (){
        if(reservationType1.isSelected()){
            return "Aller - Simple" ;
        } else if(reservationType2.isSelected()){
            return "Aller - Retour" ;
        }  
        return null;
    }
    // get the type selected
    public String radioselected1 (){
        if(type1.isSelected()){
            return "Economique" ;
        } else if(type2.isSelected()){
            return "Homme d'affaire" ;
        }  
        return null;
    }
    //*********************************************
    private String saveReservation() {
        //test all data
        if(validaPlaceNumber()&&  validatePassport () ){
            try {
                //query LIKE
                String st = "INSERT INTO reservations (passportNbr,dor, place_nbr,reservation_type,type,id_client,id_flight) VALUES (?,?,?,?,?,?,?)";
                preparedStatement = (PreparedStatement) connection.prepareStatement(st);
                preparedStatement.setString(1, passportNum.getText());
                preparedStatement.setString(2, txtDOR.getValue().toString());
                preparedStatement.setString(3, PlaceNumber.getText());
                preparedStatement.setString(4, radioselected ());
                preparedStatement.setString(5, radioselected1 ());
                preparedStatement.setString(6, idClient.getValue().toString());
                preparedStatement.setString(7, idFlight.getValue().toString());
                preparedStatement.executeUpdate();
                lblStatus.setTextFill(Color.GREEN);
                lblStatus.setText("Added Successfully");
                fetRowList();
                //clear fields
                clearFields();
                return "Success";
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                lblStatus.setTextFill(Color.TOMATO);
                lblStatus.setText(ex.getMessage());
                return "Exception";
           }
        }
        return null;
    }
    
    //only fetch columns
    private void fetColumnList() {
        try {
            ResultSet rs = connection.createStatement().executeQuery(SQL);
            //SQL FOR SELECTING ALL OF CUSTOMER
            for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                //We are using non property style for making dynamic table
                final int j = i;
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i + 1).toUpperCase());
                col.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>() {
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });
                tblData.getColumns().removeAll(col);
                tblData.getColumns().addAll(col);
                System.out.println("Column [" + i + "] ");
            }
        } catch (Exception e) {
            System.out.println("Error " + e.getMessage());
        }
    }
    //fetches rows and data from the list
    private void fetRowList() {
        data = FXCollections.observableArrayList();
        ResultSet rs;
        try {
            rs = connection.createStatement().executeQuery(SQL);
            while (rs.next()) {
                //Iterate Row
                ObservableList row = FXCollections.observableArrayList();
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    //Iterate Column
                    row.add(rs.getString(i));
                }
                System.out.println("Row [1] added " + row);
                data.add(row);
            }
            tblData.setItems(data);
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }
    //*********************************************
    @FXML
    void editReservation(ActionEvent event)throws SQLException {
        // test all data
        if(validaPlaceNumber()&&  validatePassport ()  ){
            try {
                //query LIKE
                String query = "update reservations set passportNbr=?,dor=?,place_nbr=?, reservation_type=?, type=?, id_client=?, id_flight=?  where ID='"+txtResearch.getText()+"'  ";
                preparedStatement = (PreparedStatement) connection.prepareStatement(query);
                preparedStatement.setString(1, passportNum.getText());
                preparedStatement.setString(2, txtDOR.getValue().toString());
                preparedStatement.setString(3, PlaceNumber.getText());
                preparedStatement.setString(4, radioselected ());
                preparedStatement.setString(5, radioselected1 ());
                preparedStatement.setString(6, idClient.getValue());
                preparedStatement.setString(7, idFlight.getValue());
                // preparedStatement.executeUpdate();
                lblStatus.setTextFill(Color.GREEN);
                lblStatus.setText("Reservation Successfully Updated");
                preparedStatement.execute();
                preparedStatement.close();
                fetRowList();
                clearFields();
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                lblStatus.setTextFill(Color.TOMATO);
                lblStatus.setText(ex.getMessage());
            }
        }   
    }  
    //*********************************************
    //search client by passport Number
    @FXML
    private void SearchReservation(ActionEvent event) {

            String sql = "SELECT *FROM reservations WHERE ID="+txtResearch.getText()+"";
            ResultSet rs;
            try {
                rs = connection.createStatement().executeQuery(sql);
                // search if reservation exist
                while (rs.next()) 
                {
                    //Iterate Row
                    passportNum.setText(rs.getString("passportNbr"));
                    idClient.setValue(rs.getString("id_client"));
                    idFlight.setValue(rs.getString("id_flight"));
                    ((TextField) txtDOR.getEditor()).setText(rs.getString("dor"));
                    PlaceNumber.setText(rs.getString("place_nbr"));                
                    String reservEdit = rs.getString("reservation_type");
                    if (reservEdit.equals("Aller - Simple")){
                        reservationType1.setSelected(true); 
                    }
                    else if(reservEdit.equals("Aller - Retour")){
                        reservationType2.setSelected(true);
                    }
                    String typeEdit =rs.getString("type");
                    if(typeEdit.equals("Economique")){
                        type1.setSelected(true); 
                    }
                    else if(typeEdit.equals("Homme d'affaire")){
                         type2.setSelected(true);
                    }   
                    idClient.setValue(rs.getString("id_client"));
                    idFlight.setValue(rs.getString("id_flight"));
                    passportNum.setText(rs.getString("passportNbr"));
                }   
            }catch (SQLException ex) {
                System.err.println(ex.getMessage());
            }     
    }
    @FXML
    void Initialization(ActionEvent event) {
        clearFields();
    }
}
    

